import { Component } from '@angular/core';

@Component({
  selector: 'app-game2',
  templateUrl: './game2.component.html',
  styleUrl: './game2.component.css'
})
export class Game2Component {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-game1',
  templateUrl: './game1.component.html',
  styleUrl: './game1.component.css'
})
export class Game1Component {

}

